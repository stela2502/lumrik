Valkyrn repertoire interpretation
===============================

Cells: 12960
Rearrangements: 34245
Productive rearrangements: 25417
Productive receptor families: 5945
IGH families: 2557
Expanded IGH families: 1012
IGH families with >1 productive LC partner: 825

Interpretation notes
--------------------
IGH family membership is defined primarily by Lumrik's reversible structural HC:<HEX> recombination identifier. Only calls flagged pn_alternative may use a conservative fallback requiring the same V/D/J, CDR3-AA length and naive rearrangement length. IGK/IGL LC:<HEX> identity is only allowed to form a multi-cell clone inside the same inferred IGH background; a shared light-chain rearrangement across different heavy backgrounds is treated as recurrence, not clonal evidence. Mutation classes compare Lumrik's reconstructed naive rearrangement with its error-corrected observed receptor. A mutation shared by all members of a family is a lineage-shared candidate, not proof of somatic hypermutation: recurrent changes across unrelated families using the same germline segment may indicate an unrepresented germline allele. Structure candidates are deliberately restricted to expanded IGH families with multiple observed productive light-chain partners.

