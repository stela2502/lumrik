# AUTS2 transcript-usage comparison

## Question

Does relative transcript usage within **AUTS2** differ between **LACZ** and **AUTS2-g2**? This analysis compares exactly two sample groups by design.

## What was done

Paired BAM fragments overlapping the gene were matched against immutable transcript models from `gtf_splice_index`. A fragment can remain compatible with more than one transcript; `ExactJunctionChain` and splice-compatible matches are retained at equal selection rank so a shorter annotated transcript does not exclude a longer transcript that supports the same observed splice. Transcript fractions were estimated with an EM model over transcript-compatibility equivalence classes. Per-sample sampling uncertainty was estimated by 100 fragment-bootstrap replicates with replacement, rerunning the EM for each replicate. Practical transcript identifiability was tested independently with 100 randomized EM starting mixtures while keeping the observed fragments fixed. If many distinct starts converge to the same solution, the transcript mixture is well constrained by the compatibility-class geometry; if they retain substantially different solutions, individual transcript fractions are not identifiable even when the fragment-bootstrap interval is narrow.

The figures show only transcripts whose mean inferred fraction is at least 2.0% in either group. The complete numeric results remain in `AUTS2.transcript_probability.tsv`.

## Outputs

- `AUTS2.transcript_probability.comparison.tsv` — group-level table supporting the figures.
- `AUTS2.transcript_probability.usage_bootstrap.svg` — biological-sample dot plot with within-sample 95% bootstrap intervals.
- `AUTS2.transcript_probability.usage_shift.svg` — compact transcript-usage shift plot; blue points/lines are group means and coloured points are biological samples.
- `AUTS2.transcript_probability.transcript_structure.svg` — genomic transcript structures with transcript-specific InterPro protein features projected through each CDS back onto the coding exons. Protein feature blocks therefore mirror exon geometry and never fill introns.

## Samples

- **LACZ:** 1-LACZ, 3-LACZ, 4-LACZ
- **AUTS2-g2:** 2-AUTS2-g2, 3-AUTS2-g2

## Interpretation guide

The coloured bootstrap interval answers how stable a transcript estimate is **within one BAM** under resampling of observed fragments. The grey randomized-EM interval asks a different question: whether the same fixed fragment evidence admits materially different transcript mixtures from different valid starting points. Separation between biological samples is a different source of variation. A narrow bootstrap interval therefore does not prove that a transcript is identifiable. A wide grey interval is a warning that the individual transcript abundance is underdetermined by the observed compatibility classes. Conversely, a narrow grey interval indicates practical convergence of the EM solution, but still does not prove that the annotation/model itself is complete or correct. Transcripts with zero unique fragments can still be constrained if overlapping compatibility classes jointly identify them. The comparison table therefore retains unique-fragment and splice-informative counts alongside the inferred fractions.

## Important limitation

This is a transcript-usage model, not a direct transcript-specific molecule count. Ambiguous fragments contribute probabilistically through the EM model. The SVGs are intended to make the inferred shift and its uncertainty explicit; raw splice inspection (for example a sashimi plot) remains useful as a validation/debugging view but is not the primary quantitative result.

## Plotted transcripts

- AUTS2-222 (AUTS2-222;ENST00000644359.2)
- AUTS2-224 (AUTS2-224;ENST00000644939.2)
- AUTS2-235 (AUTS2-235;ENST00001136720.1)
- AUTS2-201 (AUTS2-201;ENST00000342771.10)
- AUTS2-203 (AUTS2-203;ENST00000406775.7)
- AUTS2-217 (AUTS2-217;ENST00000611706.5)
- AUTS2-229 (AUTS2-229;ENST00000647140.1)
