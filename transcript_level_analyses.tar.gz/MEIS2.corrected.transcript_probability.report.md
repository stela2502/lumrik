# MEIS2 transcript-usage comparison

## Question

Does relative transcript usage within **MEIS2** differ between **LACZ** and **MEIS2-g3**? This analysis compares exactly two sample groups by design.

## What was done

Paired BAM fragments overlapping the gene were matched against immutable transcript models from `gtf_splice_index`. A fragment can remain compatible with more than one transcript; `ExactJunctionChain` and splice-compatible matches are retained at equal selection rank so a shorter annotated transcript does not exclude a longer transcript that supports the same observed splice. Transcript fractions were estimated with an EM model over transcript-compatibility equivalence classes. Per-sample sampling uncertainty was estimated by 100 fragment-bootstrap replicates with replacement, rerunning the EM for each replicate. Practical transcript identifiability was tested independently with 100 randomized EM starting mixtures while keeping the observed fragments fixed. If many distinct starts converge to the same solution, the transcript mixture is well constrained by the compatibility-class geometry; if they retain substantially different solutions, individual transcript fractions are not identifiable even when the fragment-bootstrap interval is narrow.

The figures show only transcripts whose mean inferred fraction is at least 2.0% in either group. The complete numeric results remain in `MEIS2.corrected.transcript_probability.tsv`.

## Outputs

- `MEIS2.corrected.transcript_probability.comparison.tsv` — group-level table supporting the figures.
- `MEIS2.corrected.transcript_probability.usage_bootstrap.svg` — biological-sample dot plot with within-sample 95% bootstrap intervals.
- `MEIS2.corrected.transcript_probability.usage_shift.svg` — compact transcript-usage shift plot; blue points/lines are group means and coloured points are biological samples.
- `MEIS2.corrected.transcript_probability.transcript_structure.svg` — genomic transcript structures with transcript-specific InterPro protein features projected through each CDS back onto the coding exons. Protein feature blocks therefore mirror exon geometry and never fill introns.

## Samples

- **LACZ:** 1-LACZ, 3-LACZ, 4-LACZ
- **MEIS2-g3:** 1-MEIS2-g3, 2-MEIS2-g3, 3-MEIS2-g3

## Interpretation guide

The coloured bootstrap interval answers how stable a transcript estimate is **within one BAM** under resampling of observed fragments. The grey randomized-EM interval asks a different question: whether the same fixed fragment evidence admits materially different transcript mixtures from different valid starting points. Separation between biological samples is a different source of variation. A narrow bootstrap interval therefore does not prove that a transcript is identifiable. A wide grey interval is a warning that the individual transcript abundance is underdetermined by the observed compatibility classes. Conversely, a narrow grey interval indicates practical convergence of the EM solution, but still does not prove that the annotation/model itself is complete or correct. Transcripts with zero unique fragments can still be constrained if overlapping compatibility classes jointly identify them. The comparison table therefore retains unique-fragment and splice-informative counts alongside the inferred fractions.

## Important limitation

This is a transcript-usage model, not a direct transcript-specific molecule count. Ambiguous fragments contribute probabilistically through the EM model. The SVGs are intended to make the inferred shift and its uncertainty explicit; raw splice inspection (for example a sashimi plot) remains useful as a validation/debugging view but is not the primary quantitative result.

## Plotted transcripts

- MEIS2-239 (MEIS2-239;ENST00000861683.2)
- MEIS2-248 (MEIS2-248;ENST00001133291.1)
- MEIS2-221 (MEIS2-221;ENST00000561208.6)
- MEIS2-207 (MEIS2-207;ENST00000557796.6)
- MEIS2-210 (MEIS2-210;ENST00000559085.5)
- MEIS2-245 (MEIS2-245;ENST00001014824.1)
- MEIS2-205 (MEIS2-205;ENST00000397624.7)
- MEIS2-244 (MEIS2-244;ENST00001014823.1)
- MEIS2-242 (MEIS2-242;ENST00000950916.2)
- MEIS2-247 (MEIS2-247;ENST00001118148.1)
- MEIS2-216 (MEIS2-216;ENST00000560570.5)
- MEIS2-203 (MEIS2-203;ENST00000340545.9)
- MEIS2-241 (MEIS2-241;ENST00000950915.2)
- MEIS2-237 (MEIS2-237;ENST00000699956.2)
- MEIS2-243 (MEIS2-243;ENST00000950917.2)
